// Exemplo de arquivo de dados para uma lista de filmes
export const filmesIniciais = [
  {
    id: 1,
    titulo: "Central do Brasil",
    ano: 1998,
    diretor: "Walter Salles",
    genero: "Drama",
    classificacao: "12"
  },
  {
    id: 2,
    titulo: "Cidade de Deus",
    ano: 2002,
    diretor: "Fernando Meirelles",
    genero: "Crime",
    classificacao: "16"
  }
];
