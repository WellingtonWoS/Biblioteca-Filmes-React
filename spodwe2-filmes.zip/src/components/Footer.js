function Footer() {
  return <footer>© 2025 Biblioteca de Filmes Brasileiros</footer>;
}

export default Footer;
